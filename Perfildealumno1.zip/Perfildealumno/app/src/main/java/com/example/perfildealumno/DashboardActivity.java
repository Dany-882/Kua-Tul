package com.example.perfildealumno;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class DashboardActivity extends AppCompatActivity {

    // Vistas del Layout Principal (Menú Lateral y Toolbar)
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    // Vistas de la nueva Interfaz de Perfil
    Button btnEditProfile;
    Button btnChangePhoto;
    TextView tvFullName;
    TextView tvUsername;
    TextView tvLevelBadge;
    ProgressBar pbExperience;
    TextView tvXpCount;
    TextView tvNextGoal;
    TextView tvTotalXpValue;

    // Vistas de la tabla de información personal (Ejemplos)
    TextView tvNameValue;
    TextView tvLastnameValue;
    TextView tvAgeValue;
    TextView tvGradeValue;
    TextView tvInstitutionValue;
    TextView tvRegistrationDate;


    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // RECIBIR userId
        userId = getIntent().getStringExtra("userId");

        // 🔥 VINCULAR VISTAS COMUNES 🔥
        drawerLayout = findViewById(R.id.dashboard_drawer);
        navigationView = findViewById(R.id.dashboard_navigation_view);
        toolbar = findViewById(R.id.dashboard_toolbar);

        // 🔥 VINCULAR VISTAS DE PERFIL (DEBES TENER ESTOS IDs EN TU XML) 🔥
        btnEditProfile = findViewById(R.id.btn_edit_profile);
        btnChangePhoto = findViewById(R.id.btn_change_photo);
        tvFullName = findViewById(R.id.tv_full_name);
        tvUsername = findViewById(R.id.tv_username);
        tvLevelBadge = findViewById(R.id.tv_level_badge);
        pbExperience = findViewById(R.id.pb_experience);
        tvXpCount = findViewById(R.id.tv_xp_count);
        tvNextGoal = findViewById(R.id.tv_next_goal);
        tvTotalXpValue = findViewById(R.id.tv_total_xp_value);

        // Vistas de la tabla de información personal
        tvNameValue = findViewById(R.id.tv_name_value);
        tvLastnameValue = findViewById(R.id.tv_lastname_value);
        tvAgeValue = findViewById(R.id.tv_age_value);
        tvGradeValue = findViewById(R.id.tv_grade_value);
        tvInstitutionValue = findViewById(R.id.tv_institution_value);
        tvRegistrationDate = findViewById(R.id.tv_registration_date);


        // 3. ASIGNAR DATOS DEL PERFIL (Ejemplo de cómo poblar la UI)
        tvFullName.setText("Ana García");
        tvUsername.setText("@ana_estudiante");
        tvLevelBadge.setText("12");

        // Experiencia
        pbExperience.setProgress(70);
        tvXpCount.setText("1750/100 XP");
        tvNextGoal.setText("Próximo objetivo: Alcanzar nivel 15");
        tvTotalXpValue.setText("2,850 XP");

        // Datos personales
        tvNameValue.setText("Ana");
        tvLastnameValue.setText("García");
        tvAgeValue.setText("16 años");
        tvGradeValue.setText("10º Grado");
        tvInstitutionValue.setText("Instituto Tecnológico San Patricio");
        tvRegistrationDate.setText("14/1/2024");

        // Nota: Si quieres que estos datos sean dinámicos, deberás cargarlos desde una base de datos (Firebase, etc.)

        setSupportActionBar(toolbar);
        // Ocultar el título para que solo se vean las "pestañas" o el ícono del menú
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("");
        }

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close
        );

        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // ------------ NAVIGATION VIEW (Mismo comportamiento) -------------
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int id = item.getItemId();

                if (id == R.id.nav_mascota) {
                    Intent i = new Intent(DashboardActivity.this, PetActivity.class);
                    i.putExtra("userId", userId);
                    startActivity(i);
                }
                if (id == R.id.nav_config) {
                    Intent i = new Intent(DashboardActivity.this, SettingsActivity.class);
                    i.putExtra("userId", userId);
                    startActivity(i);
                }
                if (id == R.id.nav_logout) {
                    // Cerrar sesión en Firebase
                    FirebaseAuth.getInstance().signOut();

                    // Volver a MainActivity
                    Intent intent = new Intent(DashboardActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        // ------------ BOTONES DE PERFIL (Nuevo comportamiento) -------------
        btnEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lógica para ir a la pantalla de edición de perfil
            }
        });

        btnChangePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lógica para abrir la galería o cámara para cambiar la foto
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}