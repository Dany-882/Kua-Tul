package com.example.perfildealumno.activity_misclases;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.perfildealumno.R;

public class misclasesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // --- 1. ENLACE DEL XML (activity_misclases) ---
        setContentView(R.layout.activity_misclases);

        // 2. Configurar la Toolbar
        Toolbar toolbar = findViewById(R.id.clases_toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("");
        }

        // 3. Configurar la lógica de los botones
        setupButtonListeners();
    }

    /**
     * Define todos los listeners de los 6 botones.
     */
    private void setupButtonListeners() {
        // Matemáticas (Azul)
        setupButton(R.id.btn_ver_mate, "Ver Clase", "Matemáticas Avanzadas");
        setupButton(R.id.btn_materiales_mate, "Materiales", "Matemáticas Avanzadas");

        // Historia (Verde)
        setupButton(R.id.btn_ver_historia, "Ver Clase", "Historia Universal");
        setupButton(R.id.btn_materiales_historia, "Materiales", "Historia Universal");

        // Ciencias (Morado)
        setupButton(R.id.btn_ver_ciencias, "Ver Clase", "Ciencias Naturales");
        setupButton(R.id.btn_materiales_ciencias, "Materiales", "Ciencias Naturales");
    }

    /**
     * Función que asigna el Listener de clic a un botón de forma segura.
     * @param buttonId El ID del botón (R.id.xxx)
     * @param action La acción (ej. "Ver Clase")
     * @param subject El nombre de la materia
     */
    private void setupButton(int buttonId, final String action, final String subject) {
        // Usamos (Button) para castear la vista a un Button
        Button button = (Button) findViewById(buttonId);

        // Comprobamos que el botón exista antes de asignarle un Listener
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(misclasesActivity.this, action + " de " + subject + "...", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}