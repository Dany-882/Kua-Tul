package com.example.perfildealumno;

public class TeacherRegistrationActivity {
}
